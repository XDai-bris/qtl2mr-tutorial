v050_input <- function(kinship = TRUE) {
  set.seed(50017)
  n <- 60L
  ids <- paste0("s", seq_len(n))
  a <- array(rexp(n * 8L * 2L), c(n, 8L, 2L), dimnames = list(ids, LETTERS[1:8], c("m1", "m2")))
  for (m in seq_len(2L)) a[, , m] <- a[, , m] / rowSums(a[, , m])
  z <- a[, , 1L] %*% make_founder_contrasts(LETTERS[1:8])
  x <- 3 * z[, 1L] + rnorm(n, sd = .2)
  pheno <- data.frame(x = x, y = .7 * x + rnorm(n, sd = .2), row.names = ids)
  G <- matrix(rnorm(n * 30L), n)
  K <- tcrossprod(G) / 60 + diag(.5, n)
  dimnames(K) <- list(ids, ids)
  list(allele_probs = list(`1` = a), pheno = pheno,
    covar = data.frame(age = seq_len(n), row.names = ids),
    kinship = if (kinship) list(`1` = K) else NULL,
    marker_map = data.frame(marker = c("m1", "m2"), chr = "1", pos = 1:2),
    selected_loci = c("m1", "m2"), exposure = "x", outcome = "y")
}

test_that("exposure and outcome must be two different named traits", {
  raw <- v050_input()
  raw$outcome <- "x"
  expect_error(do.call(as_qtl2mr_prepared_input, raw), "must be different traits")
  raw <- v050_input()
  raw$exposure <- c("x", "y")
  expect_error(do.call(as_qtl2mr_prepared_input, raw), "exposure must be one non-empty trait name")
  input <- do.call(as_qtl2mr_prepared_input, v050_input())
  expect_error(run_qtl2mr_analysis(input, exposure = "y", outcome = "y", output_dir = tempfile(), verbose = FALSE, progress = FALSE),
    "must be different traits")
})

test_that("an empty selected-locus set is rejected with a direct message", {
  for (empty in list(character(), data.frame(marker = character(), chr = character()))) {
    raw <- v050_input()
    raw$selected_loci <- empty
    expect_error(do.call(as_qtl2mr_prepared_input, raw), "selected_loci contains no loci")
  }
})

test_that("null-model hsq is reported per role and chromosome and appended to outputs", {
  input <- do.call(as_qtl2mr_prepared_input, v050_input())
  fit <- qtl2mr:::run_prepared_qtl2mr(input, "x", "y", verbose = FALSE,
    diagnostic_bootstrap_B = 0L, heterogeneity_method = "chisq")
  hsq <- fit$hsq
  expect_identical(hsq$role, c("exposure", "outcome"))
  expect_identical(hsq$chr, c("1", "1"))
  expect_identical(hsq$n_loci, c(2L, 2L))
  expect_identical(hsq$markers, c("m1;m2", "m1;m2"))
  expect_true(all(hsq$hsq_source == "reml_null_model"))
  expect_equal(hsq$hsq, c(fit$locus_blocks[[1]]$fit_x$hsq, fit$locus_blocks[[1]]$fit_y$hsq))
  expect_identical(utils::tail(names(fit$summary), 1L), "confidence_set_bounded")
  expect_false(any(c("sample_policy", "theta_so", "se_so", "ci_lower_so", "ci_upper_so") %in% names(fit$summary)))

  user <- v050_input()
  user$hsq <- 0.3
  fixed <- qtl2mr:::run_prepared_qtl2mr(do.call(as_qtl2mr_prepared_input, user), "x", "y",
    verbose = FALSE, diagnostic_bootstrap_B = 0L, heterogeneity_method = "chisq")
  expect_identical(unique(fixed$hsq$hsq_source), "user_supplied")
  expect_equal(unique(fixed$hsq$hsq), 0.3)

  ols <- qtl2mr:::run_prepared_qtl2mr(do.call(as_qtl2mr_prepared_input, v050_input(kinship = FALSE)),
    "x", "y", verbose = FALSE, diagnostic_bootstrap_B = 0L, heterogeneity_method = "chisq")
  expect_identical(unique(ols$hsq$hsq_source), "no_kinship_ols")
  warnings <- qtl2mr:::qtl2mr_warning_table(ols)
  expect_true("no_kinship_ols" %in% warnings$warning_id)
})

test_that("boundary hsq estimates are flagged and written with the analysis", {
  raw <- v050_input()
  raw$hsq <- list(exposure = 0)
  input <- do.call(as_qtl2mr_prepared_input, raw)
  out <- tempfile("qtl2mr-hsq-")
  result <- run_qtl2mr_analysis(input, output_dir = out, make_figures = FALSE, make_html = TRUE,
    verbose = FALSE, progress = FALSE, heterogeneity_method = "chisq", diagnostic_bootstrap_B = 0L,
    run_loo_mr = FALSE, run_instrument_sensitivity = FALSE)
  written <- utils::read.csv(file.path(out, "data", "hsq.csv"), stringsAsFactors = FALSE)
  expect_identical(written$role, c("exposure", "outcome"))
  expect_identical(written$hsq_source[[1L]], "user_supplied")
  expect_true(any(grepl("^Null-model hsq: ", readLines(file.path(out, "summary.md")))))
  report <- paste(readLines(file.path(out, "report.html")), collapse = "\n")
  expect_match(report, "Polygenic background")
  expect_match(report, "Values marked user_supplied were given by the user", fixed = TRUE)
  expect_match(report, "Values marked reml_null_model are estimated by REML", fixed = TRUE)
  expect_false(grepl("no_kinship_ols had no kinship", report, fixed = TRUE))
  expect_match(qtl2mr:::qtl2mr_hsq_report_note("no_kinship_ols"), "ordinary least squares")
  expect_false(grepl("REML", qtl2mr:::qtl2mr_hsq_report_note("no_kinship_ols")))

  blocks <- result$pilot$locus_blocks
  blocks[[1]]$fit_y$hsq <- 0
  blocks[[1]]$fit_y$hsq_status <- "boundary_zero"
  flagged <- qtl2mr:::qtl2mr_warning_table(list(summary = result$pilot$summary,
    hsq = qtl2mr:::qtl2mr_hsq_table(blocks, "x", "y")))
  expect_true("hsq_boundary" %in% flagged$warning_id)
  expect_match(flagged$message[flagged$warning_id == "hsq_boundary"], "outcome chr 1")
})

test_that("samples without a covariate row are reported like non-finite covariates", {
  raw <- v050_input()
  raw$covar <- raw$covar[-3L, , drop = FALSE]
  input <- suppressWarnings(do.call(as_qtl2mr_prepared_input, raw))
  expect_warning(fit <- qtl2mr:::run_prepared_qtl2mr(input, "x", "y", verbose = FALSE,
    diagnostic_bootstrap_B = 0L, heterogeneity_method = "none"), "Missing covariate rows")
  expect_true(all(fit$sample_alignment$n_missing_covar_id == 1L))
  expect_true("incomplete_covariates" %in% qtl2mr:::qtl2mr_warning_table(fit)$warning_id)
})

test_that("warnings state that exposure and outcome use their own samples", {
  input <- do.call(as_qtl2mr_prepared_input, v050_input())
  fit <- qtl2mr:::run_prepared_qtl2mr(input, "x", "y", verbose = FALSE,
    diagnostic_bootstrap_B = 0L, heterogeneity_method = "none")
  single <- qtl2mr:::qtl2mr_warning_table(fit)
  expect_true("prepared_overlap_engine" %in% single$warning_id)
  expect_false("batch_shared_samples" %in% qtl2mr:::qtl2mr_warning_catalog()$warning_id)
})

test_that("confidence_set_bounded reflects every confidence-set type", {
  f <- qtl2mr:::qtl2mr_confidence_set_bounded
  set <- function(lower, upper) data.frame(lower = lower, upper = upper)
  expect_true(f(list(confidence_set_type = "bounded", confidence_set = set(0.1, 0.9))))
  expect_false(f(list(confidence_set_type = "unbounded", confidence_set = set(0.1, Inf))))
  expect_true(f(list(confidence_set_type = "disconnected", confidence_set = set(c(-2, 1), c(-1, 2)))))
  expect_false(f(list(confidence_set_type = "disconnected", confidence_set = set(c(-Inf, 1), c(-1, Inf)))))
  expect_false(f(list(confidence_set_type = "all_real", confidence_set = set(-Inf, Inf))))
  expect_true(is.na(f(list(confidence_set_type = "unresolved", confidence_set = set(-Inf, Inf)))))
  expect_true(is.na(f(list())))
})

test_that("summary() gives a compact overview, also for results saved before 0.5.0", {
  input <- do.call(as_qtl2mr_prepared_input, v050_input())
  result <- run_qtl2mr_analysis(input, output_dir = tempfile("qtl2mr-summary-"), make_figures = FALSE,
    make_html = FALSE, verbose = FALSE, progress = FALSE, heterogeneity_method = "chisq",
    diagnostic_bootstrap_B = 0L, run_loo_mr = FALSE, run_instrument_sensitivity = FALSE)
  overview <- summary(result)
  primary <- qtl2mr_primary_result(result)
  expect_identical(overview$estimate, primary$theta_reported)
  expect_identical(overview$confidence_set_bounded, primary$confidence_set_bounded)
  old <- result
  old$pilot$summary$confidence_set_bounded <- NULL
  expect_identical(summary(old)$confidence_set_bounded, primary$confidence_set_bounded)
})
