## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")

## ----prepare------------------------------------------------------------------
library(qtl2mr)
data("qtl2mr_multilocus_example", package = "qtl2mr")
d <- qtl2mr_multilocus_example

input <- as_qtl2mr_prepared_input(
  allele_probs = d$allele_probs,
  pheno = d$pheno,
  covar = d$covar,
  kinship = d$kinship,
  marker_map = d$marker_map,
  selected_loci = d$selected_loci,
  exposure = d$exposure,
  outcome = d$outcome
)
validate_qtl2mr_input(input, require_selected_loci = TRUE)

## ----analysis, results='hide'-------------------------------------------------
result_dir <- tempfile("qtl2mr-multilocus-")
result <- run_qtl2mr_analysis(
  input,
  output_dir = result_dir,
  standardize_phenotypes = FALSE,
  make_figures = TRUE,
  make_html = TRUE,
  run_loo_mr = TRUE,
  run_instrument_sensitivity = TRUE,
  diagnostic_bootstrap_B = 500L,
  diagnostic_bootstrap_seed = 1L,
  heterogeneity_method = "chisq",
  verbose = FALSE,
  progress = FALSE
)

## ----primary------------------------------------------------------------------
primary <- qtl2mr_primary_result(result)
primary[, c("theta_reported", "reported_ci_lower", "reported_ci_upper",
            "effect_units", "confidence_set_type")]

## ----observational------------------------------------------------------------
observational <- lm(y ~ x1 + batch + age, data = cbind(d$pheno, d$covar))
coef(observational)["x1"]
confint(observational, "x1")

## ----warnings-----------------------------------------------------------------
warnings <- qtl2mr_warnings(result)
warnings[, c("warning_id", "severity")]

## ----steiger------------------------------------------------------------------
result$steiger_sensitivity[, c("n_loci", "n_loci_removed", "theta_primary",
                               "theta_steiger", "status")]

## ----loo-figure, echo=FALSE, out.width='100%', fig.alt='Change in the MR estimate when each of the 25 most influential loci is left out'----
knitr::include_graphics(file.path(result_dir, "figures", "loo_mr_top25.png"))

## ----founder-figure, echo=FALSE, out.width='100%', fig.alt='Heatmap of founder residuals for the first 30 selected loci'----
knitr::include_graphics(file.path(result_dir, "figures", "founder_residual_heatmap.png"))

## ----open-report, eval=FALSE--------------------------------------------------
# browseURL(file.path(result$output_dir, "report.html"))

