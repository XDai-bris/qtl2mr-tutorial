## ----qtl2-upstream, eval=FALSE------------------------------------------------
# library(qtl2)
# library(qtl2mr)
# map <- insert_pseudomarkers(cross$gmap, step = 1)
# genoprobs <- calc_genoprob(cross, map, error_prob = 0.002)
# allele_probs <- genoprob_to_alleleprob(genoprobs)
# kinship <- calc_kinship(genoprobs, type = "loco", omit_x = TRUE)
# 
# # Restrict the analysis to supported autosomes before scanning/fitting.
# autosomes <- intersect(as.character(1:19), names(allele_probs))
# stopifnot(length(autosomes) > 0L)
# allele_probs <- allele_probs[, autosomes]
# map <- map[autosomes]
# kinship <- kinship[autosomes]
# 
# # pheno has named numeric x/y columns; covar is a named numeric matrix or NULL.
# scan <- scan1(allele_probs, pheno[, c("x", "y"), drop = FALSE],
#               kinship = kinship, addcovar = covar)

## ----native-qtl2-bridge-------------------------------------------------------
if (requireNamespace("qtl2", quietly = TRUE)) {
  set.seed(4101)
  n <- 64L
  ids <- sprintf("bridge_%02d", seq_len(n))
  chromosomes <- c("1", "2", "X")
  gmap <- setNames(lapply(chromosomes, function(chr) {
    setNames(seq(0, 22, by = 2), paste0("c", chr, "m", 1:12))
  }), chromosomes)
  # Eight distinct biallelic founder patterns; observed genotypes are 1/2/3.
  patterns <- 1L + 2L * outer(0:7, rep(0:2, 4), function(i, j) {
    bitwAnd(bitwShiftR(i, j), 1L)
  })
  founder_geno <- lapply(gmap, function(m) {
    f <- patterns
    dimnames(f) <- list(LETTERS[1:8], names(m))
    f
  })
  geno <- lapply(founder_geno, function(f) {
    a <- sample(1:8, n, replace = TRUE)
    b <- sample(1:8, n, replace = TRUE)
    g <- (f[a, , drop = FALSE] + f[b, , drop = FALSE]) / 2
    storage.mode(g) <- "integer"
    rownames(g) <- ids
    g
  })
  cross_demo <- structure(list(
    crosstype = "do", geno = geno, founder_geno = founder_geno,
    gmap = gmap, alleles = LETTERS[1:8],
    is_x_chr = setNames(chromosomes == "X", chromosomes),
    is_female = setNames(rep(TRUE, n), ids),
    cross_info = matrix(8L, n, 1L, dimnames = list(ids, "generation"))
  ), class = "cross2")
  stopifnot(qtl2::check_cross2(cross_demo))
  bridge_map <- qtl2::insert_pseudomarkers(cross_demo$gmap, step = 1)
  bridge_genoprobs <- qtl2::calc_genoprob(
    cross_demo, bridge_map, error_prob = 0.002, cores = 1
  )
  bridge_probs <- qtl2::genoprob_to_alleleprob(bridge_genoprobs)
  bridge_kinship <- qtl2::calc_kinship(
    bridge_genoprobs, type = "loco", omit_x = TRUE
  )
  autosomes <- intersect(as.character(1:19), names(bridge_probs))
  bridge_probs <- bridge_probs[, autosomes]
  bridge_map <- bridge_map[autosomes]
  bridge_kinship <- bridge_kinship[autosomes]
  x <- 3 * bridge_probs[["1"]][, "A", 1] -
    2 * bridge_probs[["1"]][, "D", 1] + rnorm(n, sd = 0.2)
  bridge_pheno <- cbind(x = x, y = 0.25 * x + rnorm(n))
  rownames(bridge_pheno) <- ids
  bridge_scan <- qtl2::scan1(bridge_probs, bridge_pheno,
                           kinship = bridge_kinship, cores = 1)
  bridge_resources <- qtl2mr::qtl2mr_prepare_resources(
    bridge_probs, bridge_kinship, bridge_pheno, covar = NULL, marker_map = bridge_map
  )
  bridge_instruments <- qtl2mr::qtl2mr_select_instruments(
    bridge_resources, bridge_scan, exposures = "x", lod_thresh = 4, progress = FALSE
  )
  stopifnot(any(bridge_instruments$selected)) # teaching threshold, not calibration
  print(bridge_instruments[, c("marker", "chr", "lod", "F_X_block", "selected")])
  bridge_prepared <- qtl2mr::qtl2mr_pair_input(
    bridge_resources, bridge_instruments, exposure = "x", outcome = "y"
  )
  stopifnot(qtl2mr::validate_qtl2mr_input(
    bridge_prepared, require_selected_loci = TRUE
  ))
}

## ----select-and-fit, eval=FALSE-----------------------------------------------
# resources <- qtl2mr_prepare_resources(allele_probs, kinship, pheno, covar, marker_map = map)
# # Example only: choose a justified threshold for your study.
# instruments <- qtl2mr_select_instruments(resources, scan, exposures = "x", lod_thresh = 4)
# instruments[, c("exposure", "marker", "chr", "lod", "F_X_block", "selected", "drop_reason")]
# prepared <- qtl2mr_pair_input(resources, instruments, exposure = "x", outcome = "y")
# result <- run_qtl2mr_analysis(prepared, output_dir = "x-to-y")
# qtl2mr_primary_result(result)
# qtl2mr_warnings(result)

## ----batch-template, eval=FALSE-----------------------------------------------
# resources <- qtl2mr_prepare_resources(allele_probs, kinship, pheno, covar, marker_map = map)
# instruments <- qtl2mr_select_instruments(resources, scan, exposures = c("x", "w"), lod_thresh = 4)
# pairs <- data.frame(exposure = c("x", "x", "w"), outcome = c("y", "z", "z"))
# batch <- run_qtl2mr_batch(resources, pairs, instruments,
#                           output_dir = "batch-results", n_workers = 4)
# batch$main_results[, c("pair_id", "status", "theta_reported",
#                        "reported_ci_lower", "reported_ci_upper")]
# # After an interruption, the same call with resume = TRUE continues the run.
# detail <- run_qtl2mr_analysis(qtl2mr_pair_input(resources, instruments, "x", "z"),
#                               output_dir = "x-to-z")

