## ----setup, include=FALSE-----------------------------------------------------
knitr::opts_chunk$set(collapse = TRUE, comment = "#>")

## ----load-example-------------------------------------------------------------
library(qtl2mr)
data("qtl2mr_example", package = "qtl2mr")

## ----prepare-input------------------------------------------------------------
prepared <- as_qtl2mr_prepared_input(
  allele_probs = qtl2mr_example$allele_probs,
  pheno = qtl2mr_example$pheno,
  covar = qtl2mr_example$covar,
  kinship = qtl2mr_example$kinship,
  marker_map = qtl2mr_example$marker_map,
  selected_loci = qtl2mr_example$selected_loci,
  exposure = qtl2mr_example$exposure,
  outcome = qtl2mr_example$outcome,
  metadata = qtl2mr_example$metadata
)
stopifnot(validate_qtl2mr_input(prepared, require_selected_loci = TRUE))

## ----quick-analysis, results='hide'-------------------------------------------
result_dir <- tempfile("qtl2mr-getting-started-")
result <- run_qtl2mr_analysis(
  prepared,
  output_dir = result_dir,
  overwrite = TRUE,
  make_figures = FALSE,
  make_html = TRUE,
  verbose = FALSE,
  diagnostic_bootstrap_B = 0L,
  heterogeneity_method = "chisq",
  run_loo_mr = FALSE,
  run_instrument_sensitivity = FALSE,
  progress = FALSE
)

## ----read-accessors, results='hide'-------------------------------------------
primary <- qtl2mr_primary_result(result)
warnings <- qtl2mr_warnings(result)

## ----prepare-result-tables, include=FALSE-------------------------------------
primary_view <- data.frame(
  estimator = primary$reported_estimator,
  estimate = primary$theta_reported,
  `95% CI` = sprintf("[%.3f, %.3f]", primary$reported_ci_lower, primary$reported_ci_upper),
  primary_reliable = primary$primary_reliable,
  row.names = NULL,
  check.names = FALSE
)

actionable_warnings <- warnings[warnings$shown_in_main_report %in% TRUE,
  c("warning_id", "severity"), drop = FALSE]
rownames(actionable_warnings) <- NULL

## ----read-result, echo=FALSE--------------------------------------------------
knitr::kable(primary_view, digits = 3)
knitr::kable(actionable_warnings)

## ----first-stage--------------------------------------------------------------
first_stage <- read.csv(file.path(result_dir, "data", "block_first_stage.csv"))
first_stage[, c("marker", "F_X_block", "partial_R2_X_block", "partial_R2_Y_block", "steiger_pass")]

## ----kinship-example, results='hide'------------------------------------------
set.seed(401)
ids <- rownames(qtl2mr_example$pheno)
background <- matrix(rnorm(length(ids) * 24L), nrow = length(ids))
K <- tcrossprod(background) / ncol(background)
K <- (K / mean(diag(K)) + diag(length(ids))) / 2
dimnames(K) <- list(ids, ids)
prepared_lmm <- as_qtl2mr_prepared_input(
  allele_probs = qtl2mr_example$allele_probs, pheno = qtl2mr_example$pheno,
  covar = qtl2mr_example$covar, kinship = list("1" = K),
  marker_map = qtl2mr_example$marker_map, selected_loci = qtl2mr_example$selected_loci,
  exposure = qtl2mr_example$exposure, outcome = qtl2mr_example$outcome
)
lmm_dir <- tempfile("qtl2mr-lmm-")
lmm_result <- run_qtl2mr_analysis(
  prepared_lmm, output_dir = lmm_dir, make_figures = FALSE,
  verbose = FALSE, diagnostic_bootstrap_B = 0L,
  heterogeneity_method = "none", run_loo_mr = FALSE,
  run_instrument_sensitivity = FALSE, progress = FALSE
)

## ----kinship-hsq--------------------------------------------------------------
read.csv(file.path(lmm_dir, "data", "hsq.csv"))[, c("role", "trait", "hsq", "hsq_status")]
summary(lmm_result)$estimate

## ----cleanup, include=FALSE---------------------------------------------------
unlink(result_dir, recursive = TRUE, force = TRUE)
unlink(lmm_dir, recursive = TRUE, force = TRUE)

